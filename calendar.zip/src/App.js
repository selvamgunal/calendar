import MyCalendar from './Calendar/Calendar';
import './App.css';

function App() {
  return (
    <div className="App">
      <MyCalendar/>
    </div>
  );
}

export default App;
